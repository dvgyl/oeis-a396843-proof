# AI-developed proofs for A396099 and related compositional series

**Author: Dev Goyal.** Prepared 24 October 2026.

This package contains mathematical proofs and a Lean 4 formalization of all four conjectures recorded for [OEIS A396099](https://oeis.org/A396099), a general theorem that explains them, and the related results listed below. Start with **`manuscript/compositional_congruences.pdf`** for the complete readable argument.

> **AI disclosure:** ChatGPT (OpenAI) generated the proofs, manuscript, Lean code, verification programs, and documentation autonomously from Dev Goyal's prompts. Dev Goyal is the sole human author. Independent human review of this new work is pending. See `AI_DISCLOSURE.md` for the full contribution and review statement.

## Results included

Write `F^(circ k)` for composition k times, with negative k defined through the compositional inverse. For each positive integer r there is a unique series F_r = X + O(X²) satisfying

\[
F_r=X+F_r^{\circ r}F_r^{\circ(r+1)}.
\]

The general theorem, including every integer k, is

\[
F_r^{\circ k}\equiv\frac{X}{1-kX}+
\begin{cases}
\displaystyle\frac{rX^4}{(1-X)^3},&r\text{ even and }k\text{ odd},\\
0,&\text{otherwise},
\end{cases}
\pmod{2r}.
\]

Its exact order under composition modulo 2r is 2r. The Lean development proves existence, uniqueness, reduction compatibility, actual inverse construction, and this formula before deriving the named coefficient claims.

| Entry | Included result |
|---|---|
| **A396099** | All four assertions: all positive coefficients odd; period 1,3,3,1 modulo four from n = 3; the second iterate has no coefficients above degree two modulo four; coefficients of F − X F^(circ 3) are two modulo four for n > 2. |
| **A396798** | All seven iterate assertions, a proof that the stated starting-at-one coefficient phase is false, and the corrected period 1,1,5,5 modulo eight from **n = 2**. |
| **A396807** | Coefficients are one modulo ten; every integer iterate has coefficient k^(n−1) modulo ten, including negative k. |
| **A393856** | Coefficients are one modulo five; a coefficient is odd exactly at a power-of-two index. |
| **A393857** | Coefficients are one modulo six. |
| **A393858** | Coefficients are one modulo seven; a coefficient is odd exactly at a power-of-two index. |
| **A393859** | Coefficients are one modulo eight. |

The second family is defined by G_q(X − X G_q(qX)/q) = X. Its formalization removes the division by q coefficientwise, proves existence and uniqueness over arbitrary commutative rings, and proves the general modulus q+1 and parity results. The six named applications follow directly.

The r = 3 case, A396797, was previously proved by Shiva Priyan Shanmuga Sundaram and is credited as prior work. No exclusive-priority claim is made. The archive also retains the original A396843 project's Lean source, checks its 16 acceptance theorems as regressions, and includes its reference manuscript source.

## What to read

- `manuscript/compositional_congruences.pdf`: complete mathematical paper.
- `manuscript/compositional_congruences.tex`: editable LaTeX source.
- `lean/Consecutive/Acceptance.lean`: a single theorem giving all four A396099 conclusions directly from the literal original functional equation for any normalized integer series.
- `docs/COVERAGE.md`: result-by-result map to exact Lean declarations.
- `docs/THEOREM_SPEC.md`: intended mathematical statements and index ranges.
- `docs/FORMAL_REVIEW.md` and `docs/INTEGER_ITERATES_REVIEW.md`: AI-assisted semantic reviews and their limitations.
- `docs/RELATED_CONJECTURES.md`: source status, attribution, and the phase correction.
- `reproducibility/lean_complete/`: fresh build, typed-contract, printed-type, and axiom evidence.
- `reproducibility/coefficients_40.json`: independent finite coefficient checks.
- `AI_DISCLOSURE.md`, `CITATION.cff`, and `docs/PROVENANCE.md`: authorship and provenance.

## Reproduce the formal checks

Required: Python 3.11 or later and an installation of Lean's Elan/Lake toolchain manager. The package pins **Lean 4.19.0** and **Mathlib commit `c44e0c8ee63ca166450922a373c7409c5d26b00b`**. Downloaded dependencies and compiler binaries are not bundled.

From the extracted package:

```sh
cd lean
lake exe cache get
lake build
cd ..
python3 scripts/check_formalization.py
```

The checker cleans and rebuilds the first-party package while retaining pinned dependency caches. It then compiles the explicit contracts in `lean/ContractChecks.lean`, records fully elaborated theorem types, and audits transitive axiom dependencies against a fixed list of required endpoints. It also records source hashes before and after validation and rejects a changed source tree. See the generated `reproducibility/lean_complete/report.json` for the executed commands and results.

The allowed axioms are only `propext`, `Classical.choice`, and `Quot.sound`, the standard logical foundations used by Lean/Mathlib. The audit rejects admitted proofs (`sorryAx`) and any additional mathematical axiom. The proof source does not use `sorry`, `admit`, `native_decide`, or custom axioms.

## Reproduce the independent coefficient checks

```sh
python3 -m unittest discover -s tests -v
python3 scripts/verify_coefficients.py --terms 40 --output reproducibility/coefficients_40.json
```

The constructors recover exact integer coefficients from the original functional equations. They do not generate coefficients from the desired congruence formulas. The default run performs **6,416 coefficient checks** through degree 40 for r = 1,…,8 and q = 1,…,8, including the named assertions and the published initial coefficients. The test suite contains 32 tests, including adversarial tests of the axiom-audit parser and fixed validation requirements.

Finite checks are corroboration. The Lean theorems and mathematical arguments apply to every index. The finite checker tests natural iterates; the full signed-iterate theorem is proved in Lean separately.

## Build the manuscript

With pdfLaTeX and the packages used in the source installed:

```sh
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error compositional_congruences.tex
pdflatex -interaction=nonstopmode -halt-on-error compositional_congruences.tex
```

The supplied PDF was rendered and visually inspected. `SHA256SUMS` records the archive's payload checksums. After extraction, `sha256sum -c SHA256SUMS` checks them on systems providing that command.

The source repository used for author details and reusable infrastructure is [dvgyl/oeis-a396843-proof](https://github.com/dvgyl/oeis-a396843-proof), revision `995e55adcbe06b2a913e24f12ff73a7faf362f06`. Its existing DOI belongs to the earlier work and has not been reused for this package.
