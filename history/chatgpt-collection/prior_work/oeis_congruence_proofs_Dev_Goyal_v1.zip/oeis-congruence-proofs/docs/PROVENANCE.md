# Provenance and scope

## Reference project

- Owner and sole human author: **Dev Goyal**.
- Reference repository: <https://github.com/dvgyl/oeis-a396843-proof>.
- Inspected revision: `995e55adcbe06b2a913e24f12ff73a7faf362f06`.
- Author metadata source: the repository's `CITATION.cff` at that revision.
- New package date: 24 October 2026.

The reference project's DOI, `10.5281/zenodo.23567463`, belongs to the earlier A396843 work. It has **not** been assigned to this new package. The reference project has no declared affiliation in its citation metadata, so this package supplies none.

The original `lean/Hanna` sources are retained, with new files under `Hanna/Related`. In particular the existing formal-power-series, substitution, filtration, triangular recursion, and inverse constructions are reused. The old `Hanna.Acceptance` theorems are checked as regression endpoints and are not presented as new discoveries. The original manuscript source and README appear under `prior_work` as reference material. Their author-review statements concern that earlier project only.

New mathematics and formalization live under `lean/Consecutive` and `lean/Hanna/Related`. Their canonical sequences are constructed from their own original functional equations. They are not aliases for the rational comparison series. Equality with a comparison series after coefficient reduction is a proved theorem.

## New scope

The main target is A396099, defined by F = X + F composed twice times F composed three times. All four listed assertions are treated as universal statements. The general consecutive-iterate result covers every natural parameter and every nonnegative iterate, and the signed-iterate extension uses actual compositional inverses.

Direct applications include A396798 and A396807. One A396798 statement is false with its published starting phase: the corrected coefficient block begins at n = 2. The other seven statements follow from the general theorem. The r = 3 case A396797 was already proved by Sundaram and is credited as prior work.

A separate division-free scaled-substitution family gives six assertions from A393856–A393859. The source ledger identifies every original statement and its index range.

No claim is made that every conjecture in OEIS or every conjecture adjacent to these entries has been resolved. The scope is the explicit statement list in `docs/THEOREM_SPEC.md`, with exact formal coverage in `docs/COVERAGE.md` and `validation/final_theorems.json`.

## Reproducibility boundaries

The archive contains first-party source, the pinned Lean and Mathlib versions, the mathematical PDF and its LaTeX source, and the fresh verification evidence. It omits downloaded compiler binaries and dependency caches. The setup commands fetch those exact pinned dependencies.

Compilation and axiom audits establish the proof terms against their formal types. The typed contracts and definition review document how those types correspond to the mathematical questions. Finite coefficient checks are separate computational corroboration. All preparation and review in this session were AI-assisted; independent human review remains pending.
