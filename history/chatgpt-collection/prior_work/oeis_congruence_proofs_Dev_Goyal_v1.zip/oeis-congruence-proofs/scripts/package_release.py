#!/usr/bin/env python3
"""Package validated first-party source, manuscript, and evidence.

The archive deliberately omits downloaded dependency caches and compiler
binaries. Run the formal checker before packaging. SHA256SUMS covers every
payload file except itself; ZIP CRCs and the embedded hashes are rechecked.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile


EXCLUDED_PARTS = {".lake", ".git", "__pycache__", ".pytest_cache"}
EXCLUDED_SUFFIXES = {".pyc", ".aux", ".out", ".synctex", ".fls", ".fdb_latexmk"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload(root: Path) -> list[Path]:
    result = []
    for path in root.rglob("*"):
        rel = path.relative_to(root)
        if any(part in EXCLUDED_PARTS for part in rel.parts):
            continue
        if path.is_symlink():
            raise ValueError(f"Unexpected symlink in release payload: {rel}")
        if not path.is_file() or path.suffix in EXCLUDED_SUFFIXES:
            continue
        if path.name == "SHA256SUMS" or path.suffix == ".zip":
            continue
        result.append(path)
    return sorted(result)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.repo.resolve()
    archive = (args.output or root.parent / "oeis_congruence_proofs_Dev_Goyal.zip").resolve()
    if archive.is_relative_to(root):
        raise ValueError("Write the archive outside its own payload directory")
    report = json.loads((root / "reproducibility/lean_complete/report.json").read_text())
    if report.get("status") != "mechanical_checks_passed":
        raise ValueError("The formal verification report does not record a successful run")
    before = report.get("sources_before")
    after = report.get("sources_after")
    if not before or before != after:
        raise ValueError("Missing or unequal source snapshots in the verification report")
    for rel, expected in after.items():
        if digest(root / rel) != expected:
            raise ValueError(f"Source changed after formal validation: {rel}")
    for command in report.get("commands", []):
        if command["exit_code"] != 0:
            raise ValueError("Verification command failed")
        log = root / "reproducibility/lean_complete" / command["log"]
        if digest(log) != command["log_sha256"]:
            raise ValueError(f"Verification log changed: {log.name}")
    files = payload(root)
    sums = "".join(f"{digest(path)}  {path.relative_to(root).as_posix()}\n" for path in files)
    checksum_file = root / "SHA256SUMS"
    checksum_file.write_text(sums)
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path in [*files, checksum_file]:
            name = f"{root.name}/{path.relative_to(root).as_posix()}"
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 24, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 << 16)
            out.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as check:
        bad = check.testzip()
        if bad is not None:
            raise ValueError(f"Archive CRC failed: {bad}")
        for path in files:
            name = f"{root.name}/{path.relative_to(root).as_posix()}"
            actual = hashlib.sha256(check.read(name)).hexdigest()
            if actual != digest(path):
                raise ValueError(f"Archive payload mismatch: {name}")
    print(json.dumps({
        "status": "archive_verified",
        "archive": str(archive),
        "files": len(files) + 1,
        "bytes": archive.stat().st_size,
        "sha256": digest(archive),
        "formal_source_hashes_verified": len(after),
    }, indent=2))


if __name__ == "__main__":
    main()
