"""Regression tests ensuring complete validation cannot silently lose scope."""

import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from audit_axioms import AuditError
from check_formalization import FINAL_NAMES, source_snapshot, validate_manifest


class ValidationRequirementTests(unittest.TestCase):
    def manifest(self):
        return json.loads((ROOT / "validation/final_theorems.json").read_text())

    def test_complete_manifest_retains_fixed_endpoints(self):
        self.assertEqual(validate_manifest(self.manifest()), FINAL_NAMES)

    def test_missing_endpoint_rejected(self):
        manifest = self.manifest()
        manifest["required_theorems"].pop()
        with self.assertRaises(AuditError):
            validate_manifest(manifest)

    def test_replaced_endpoint_rejected(self):
        manifest = self.manifest()
        manifest["required_theorems"][0] = "Consecutive.unrelated_theorem"
        with self.assertRaises(AuditError):
            validate_manifest(manifest)

    def test_weakened_imports_rejected(self):
        manifest = self.manifest()
        manifest["imports"] = ["Hanna.Acceptance"]
        with self.assertRaises(AuditError):
            validate_manifest(manifest)

    def test_substitute_contract_file_rejected(self):
        manifest = self.manifest()
        manifest["contract_check_file"] = "OtherContracts.lean"
        with self.assertRaises(AuditError):
            validate_manifest(manifest)

    def test_changed_pins_rejected(self):
        for key in ("expected_toolchain", "expected_mathlib_revision", "package_name"):
            with self.subTest(key=key):
                manifest = self.manifest()
                manifest[key] = "other"
                with self.assertRaises(AuditError):
                    validate_manifest(manifest)

    def test_baseline_mode_rejected(self):
        manifest = self.manifest()
        manifest["mode"] = "baseline"
        with self.assertRaises(AuditError):
            validate_manifest(manifest)

    def test_snapshot_includes_root_docs_and_final_pdf(self):
        with tempfile.TemporaryDirectory() as folder:
            repo = Path(folder)
            (repo / "README.md").write_text("reviewed documentation")
            (repo / "manuscript").mkdir()
            (repo / "manuscript/paper.pdf").write_bytes(b"test document")
            output = repo / "reproducibility/lean_complete"
            output.mkdir(parents=True)
            (output / "report.json").write_text("generated output")
            before = source_snapshot(repo, output)
            self.assertEqual(set(before), {"README.md", "manuscript/paper.pdf"})
            (repo / "README.md").write_text("changed documentation")
            self.assertNotEqual(before, source_snapshot(repo, output))

    def test_snapshot_rejects_first_party_symlink(self):
        with tempfile.TemporaryDirectory() as folder:
            repo = Path(folder)
            (repo / "proof.lean").write_text("import Mathlib")
            (repo / "alias.lean").symlink_to(repo / "proof.lean")
            with self.assertRaises(AuditError):
                source_snapshot(repo, repo / "reproducibility/lean_complete")


if __name__ == "__main__":
    unittest.main()
