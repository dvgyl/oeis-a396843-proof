# Combined OEIS proof package — version 2

**Author: Dev Goyal. Prepared 24 October 2026.**

This expanded archive contains proofs of **seven additional statements marked as conjectures in four retrieved OEIS entries**, a general inverse-iterate theorem, and **seven additional formalizations of previously proved periodicity results**. It retains all earlier proofs and includes the complete previous ZIP unchanged.

Start with **`manuscript/further_oeis_proofs.pdf`** for the new mathematics and **`manuscript/compositional_congruences.pdf`** for the previous work. Both have editable LaTeX sources. The combined Lean verification requirement set contains **130 endpoints: all 67 previous endpoints plus 63 additions**. This count includes construction and supporting theorems; it is not a count of open problems.

> **AI disclosure:** ChatGPT (OpenAI) generated the new mathematical arguments, formalization, manuscripts, verification programs, and AI-assisted reviews in response to Dev Goyal's prompts. Dev Goyal is the sole human author. **Independent human review is pending.** Earlier mathematical results and adapted upstream code are credited separately. See `AI_DISCLOSURE.md`.

## Newly added conjectural statements

The four official pages below still labeled these statements conjectures when retrieved on 24 October 2026. We provide proofs of the precise statements; this is not a guarantee of worldwide novelty, publication priority, or OEIS acceptance. Two of the seven assertions are straightforward instances of standard Frobenius.

| Entry | Results proved for every allowed index |
|---|---|
| [A396093](https://oeis.org/A396093) | Both parity assertions. For the actual third composition of `B(x)=x/(1−x)²`, `a(n)` is odd exactly when `n mod 10` is `1,3,7,9`. In particular, every even-index term is even, and `a(2n−1)` is even exactly when `n=5k−2` for some `k≥1`. |
| [A389474](https://oeis.org/A389474) | Both marked conjectures. The stronger whole-series identity is `A(x)² ≡ x²+2x³ (mod 9)`, so every square coefficient above degree three vanishes modulo nine. Also `A(x)^(3k) ≡ A(x³)^k (mod 3)` for every `k≥0`; the latter is standard Frobenius. |
| [A389475](https://oeis.org/A389475) | Both marked conjectures: `A(x)³ ≡ A(x³) (mod 3)` and `A(x)² ≡ x²+2A(x³) (mod 3)`. The cube identity is standard Frobenius; the square identity also uses this sequence's defining equation. |
| [A396102](https://oeis.org/A396102) | Every positive-index coefficient is `1 mod 3`. Lean constructs the integer series and proves its literal equation `A(A(A(x)))=(1+x)A(A(x))`, together with uniqueness. |

The cubic and inverse-iterate developments first prove existence of the normalized integer series, then prove their original equations, uniqueness, and congruences. The sequence definitions are not aliases for the desired rational comparison series.

### General inverse-iterate theorem

For each integer `r≥1`, there is a unique normalized integral series `F_r` satisfying

\[
F_r^{\circ r}(x)=(1+x)F_r^{\circ(r-1)}(x).
\]

For every natural `k≥0` and positive `n`,

\[
[x^n]F_r^{\circ k}(x)\equiv k^{n-1}\pmod r.
\]

In particular, `F_r(x) ≡ x/(1−x) (mod r)`. A396102 is `r=3`. The proof constructs the unique auxiliary series `R_r=x−R_r R_r^(circ r)` and takes its genuine compositional inverse. It proves both directions of the correspondence with the original equation.

## Seven credited formalizations of known periodicity results

For **arbitrary integer weights** `c_k`, including negative values, set

\[
b_n=\sum_{k=0}^n c_k k!S(n,k).
\]

Lean proves that `b(n+φ(m)) ≡ b(n) (mod m)` whenever `m>0` and `n≥m`. It also proves that the **least positive period of the tail starting at `m` exists and divides `φ(m)`**. The onset `m` is a sufficient bound, not a claim of optimality.

The exact named specializations are **A052895, A064618, A354242, A167137, A305550, A306082, and A080253**. The weights are defined by actual Catalan numbers, factorials, binomial coefficients, integer-partition cardinalities, or the relevant Pell recurrence.

**These seven cases are not newly solved open problems.** Payam Danesh's [26 August 2026 preprint](https://doi.org/10.33774/coe-2026-4d6jr), Theorem 4.1 and Corollary 4.2, already covers every integral substitution `G(exp(x)−1)` and gives the stronger Carmichael period. The archive credits this result and Schreyer's earlier Fubini work. Some OEIS entries still retain conjecture wording, which does not establish current openness.

The Lean result is the exact finite Stirling-transform statement above. Its identification with the coefficient sequence of the formal exponential generating function `G(exp(x)−1)` is explained in the manuscript and **is not separately claimed as a Lean theorem**. No proof is claimed here for the separate continued-fraction conjecture in A354242 or the separate power/logarithm integrality conjecture in A167137.

## Everything retained from the previous package

| Previous entry or family | Retained scope |
|---|---|
| A396099 | All four assertions, with the general consecutive-iterate theorem. |
| A396798 | Seven iterate assertions; refutation of the literal incorrect initial phase and proof of the corrected residue block starting at index 2. |
| A396807 | Both assertions, including all integer iterates through genuine compositional inverses. |
| A393856, A393857, A393858, A393859 | All six previously handled modulus and parity assertions, with the general scaled-inverse family. |
| Original A396843 project | All 16 `Hanna.Acceptance` endpoints and their supporting source, plus the original manuscript source and author/provenance records. |

All previous Lean proof modules are unchanged. The previous contract text is retained, and the fresh checker verifies its preservation. The complete previous 509,323-byte ZIP is also included at:

`prior_work/oeis_congruence_proofs_Dev_Goyal_v1.zip`

Its unchanged SHA-256 is:

```text
04f347b0e116a1c92cd7a1f21f38a37ae3dfb71c733dd5f55769accd0714489c
```

The earlier credited A396797 proof and all prior qualifications remain in the retained manuscript and original archive. The source repository is [dvgyl/oeis-a396843-proof](https://github.com/dvgyl/oeis-a396843-proof), revision `995e55adcbe06b2a913e24f12ff73a7faf362f06`. Its earlier DOI has not been assigned to this expanded release.

## Proofs, reviews, and evidence

- `manuscript/further_oeis_proofs.pdf` and `.tex`: all new mathematical arguments and historical qualifications.
- `manuscript/compositional_congruences.pdf` and `.tex`: complete previous mathematical paper.
- `lean/More/`: new Lean developments; `More/Contracts.lean` states exact semantic contracts.
- `docs/ROUND2_COVERAGE.md`: result-by-result source and theorem map, with precise quantifiers.
- `docs/CUBIC_REVERSION.md`, `docs/INVERSE_ITERATE.md`, and `docs/STIRLING_PERIODICITY.md`: detailed mathematics and source scope.
- `docs/RATIONAL_PARITY_REVIEW.md`, `docs/CUBIC_INDEPENDENT_REVIEW.md`, and `docs/ROUND2_REVIEW.md`: independent AI-assisted implementation reviews and their limits.
- `validation/final_theorems.json`: all 130 fixed required endpoints.
- `reproducibility/lean_complete/`: fresh complete build, typed-contract, printed-type, and axiom-audit records.
- `validation/*numeric.json` and `validation/inverse_iterate_checks.json`: independent finite corroboration for the additions.
- `prior_work/oeis_congruence_proofs_Dev_Goyal_v1.zip`: the exact previous deliverable, including its original records.
- `third_party/mathlib/`: required attribution and Apache-2.0 license for the adapted upstream Stirling recurrence and power-expansion proof.

## Reproduce the Lean verification

Requirements: Python 3.11 or later, and Lean's Elan/Lake toolchain manager. The package pins **Lean 4.19.0** and **Mathlib `c44e0c8ee63ca166450922a373c7409c5d26b00b`**. Compiler binaries and downloaded dependency caches are not bundled; the source, lockfile, and instructions needed to retrieve them are included.

```sh
cd lean
lake exe cache get
lake build
cd ..
python3 scripts/check_formalization.py
```

The complete checker removes the first-party build cache, rebuilds all four proof libraries, compiles the old and new explicit contracts, prints full theorem types, and checks transitive axiom dependencies for every fixed endpoint. It verifies the actual toolchain and Mathlib revision, source hashes before and after the run, and preservation of the previous release.

The allowed axioms are only **`propext`, `Classical.choice`, and `Quot.sound`**. The checker rejects missing or extra audit records, warnings/errors, and additional axioms such as `sorryAx`. The proof sources contain no `sorry`, `admit`, `native_decide`, or custom mathematical axioms. Lean's logical verification does not independently establish publication priority or validate the English-to-formal translation; the contracts and review documents address that translation explicitly.

## Reproduce the numerical checks

```sh
python3 -m unittest discover -s tests -v
python3 scripts/verify_coefficients.py --terms 40 --output reproducibility/coefficients_40.json
python3 scripts/verify_rational_parity.py --output validation/rational_parity_numeric.json
python3 scripts/verify_cubic_reversion.py --degree 40 --output validation/cubic_reversion_numeric.json
python3 tests/check_inverse_iterate.py --degree 40 --output validation/inverse_iterate_checks.json
python3 scripts/verify_stirling_periodicity.py --max-modulus 128 --output validation/stirling_numeric.json
```

The new checks match the displayed OEIS prefixes and test the actual defining equations. Cubic and inverse-iterate coefficients are checked through degree 40. Rational parity is checked through degree 2000, with separate direct-composition and double-sum checks. The Stirling suite performs 81,376 period comparisons and 49,920 scalar-power comparisons. These finite computations corroborate the universal proofs; they do not replace them.

## Build the papers and archive

Run pdfLaTeX twice on each `.tex` file from `manuscript/`. The supplied PDFs were rendered and visually inspected. After a successful complete formal-validation run, rebuild the expanded archive with:

```sh
python3 scripts/package_release.py
```

The packager verifies source and log hashes before writing the ZIP, then rechecks every payload hash and the ZIP CRCs. `SHA256SUMS` covers the payload, including the embedded original ZIP. On systems providing `sha256sum`, run `sha256sum -c SHA256SUMS` after extraction.
