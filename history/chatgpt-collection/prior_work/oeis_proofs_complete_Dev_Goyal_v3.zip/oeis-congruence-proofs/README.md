# Combined OEIS proof package — version 3

**Author: Dev Goyal. Prepared 24 October 2026.**

This release adds complete Lean proofs of **six more statements labeled as conjectures in the retrieved OEIS entries**: A397588, A389536, A389537, A389542, A378580, and A378581. It retains all earlier mathematics, proof source, manuscripts, and both previous ZIP deliverables unchanged. The new proofs cover every allowed index.

Start with **`manuscript/six_more_oeis_proofs.pdf`** for this round. The two earlier papers and all three editable LaTeX sources are included. The complete verification set now has **226 fixed endpoints: all 130 from version 2 plus 96 additions**. This count includes existence, uniqueness, source-equation, transport, and acceptance theorems; it is not a count of solved open problems.

> **AI disclosure:** ChatGPT (OpenAI) generated the added mathematical arguments, Lean proofs, manuscripts, verification programs, and AI-assisted reviews in response to Dev Goyal's prompts. Dev Goyal is the sole human author. **Independent human review is pending.** Source conjectures, prior results, and adapted upstream code retain their separate credits. See `AI_DISCLOSURE.md`.

## Six additional conjecture statements proved

Write `a(n)=[x^n]A(x)`. The first four series below have `A=x+O(x²)`; the last two have constant term one. Let `Theta(x)=1+2 sum(j≥1) x^(j²)`. Every exponent `k` below is a nonnegative integer.

| Entry | Literal source equation | Proven coefficient classification |
|---|---|---|
| [A397588](https://oeis.org/A397588) | `A=x+(xA²)'` | For every `n≥1`, `a(n)` is odd exactly when `n=2^k`. The Lean theorem also handles `n=0`. |
| [A389536](https://oeis.org/A389536) | `A(x²+2x³)=xA(x)` | For `n>1`, the residue is `2 mod 4` exactly when `n=2^k+1`, and is `0 mod 4` otherwise. |
| [A389537](https://oeis.org/A389537) | `A(A(x)−x)=A(x)²` | For `n>2`, the residue is `2 mod 4` exactly when `n=3·2^k`, and is `0 mod 4` otherwise. |
| [A389542](https://oeis.org/A389542) | `A(A(x)²−x²)=4A(x)³` | For `n>1`, the residue is `2 mod 4` exactly when `n=2^k+1`, and is `0 mod 4` otherwise. |
| [A378580](https://oeis.org/A378580) | `A(x/A(x))=Theta(x)` | For `n>0`, the residue is `2 mod 4` exactly at square indices, and is `0 mod 4` at nonsquare indices. |
| [A378581](https://oeis.org/A378581) | `A(xA(x))=Theta(x)` | The same complete square-index classification for `n>0`. |

The stronger series identity `A ≡ Theta (mod 4)` is proved for both theta entries. A related A397588 result, `3 | a(n)` for `n>1`, is also formalized. That divisibility assertion already appears in the source without a conjecture label and is **not counted as another newly solved conjecture**.

All six entries credited their sequences and conjectures to **Paul D. Hanna** and still displayed the selected assertions as conjectures when inspected on 24 October 2026. Exact-identifier and formula searches did not locate an earlier proof of these particular assertions. This is a bounded status check, not a guarantee of global novelty, exclusive priority, publication, or OEIS acceptance. The precise source ledger is `docs/ROUND3_COVERAGE.md`.

## What makes the formalization complete

The integral sequences are constructed from their equations. Each has a proved literal source equation and an existence-and-uniqueness result. Comparisons with simpler residue series occur only after that construction. The original equation's normalizations and index restrictions are retained in explicit typed acceptance contracts.

The core mathematical mechanisms are:

- **A397588:** reduction of the formal differential equation modulo two gives `A−A²=x`, whose coefficients occur exactly at binary-power indices.
- **A389536:** the integral Mahler equation has a triangular recursion; modulo four its solution is `x+2xL`, where `L−L²=x`.
- **A389537:** construct the genuine inverse from `R+R(x²)=x`. Prove `A≡x+x² (mod 2)`, halve the even integer remainder exactly, and show its reduction satisfies `H+H²=x³`.
- **A389542:** construct `L=x+L²−2xL(4x³)`, set `R=x−2xL`, and take its genuine compositional inverse. The source equation is equivalent to `R²+R(4x³)=x²`; modulo four, `R` is its own inverse.
- **The theta pair:** for any constant-one target `T`, construct the unique normalized `G` satisfying `G∘G=GT`. This yields actual solutions of `A(xA)=T` and `A(x/A)=T`. Modulo four, `Theta` itself solves both because its nonconstant part is twice an integral series and `Theta²=1`.

Integer halving is used only after its exactness is proved. The residue-ring arguments do not cancel a zero divisor. Compositional and multiplicative inverses are separate constructions with explicit inverse identities.

## All previous work retained

| Earlier scope | Retained results |
|---|---|
| Version 2: A396093 | Both parity assertions and the complete period-ten residue classification. |
| Version 2: A389474, A389475 | Both marked assertions for each entry, including the stronger square identities; standard Frobenius consequences remain explicitly identified as standard. |
| Version 2: A396102 | Every positive coefficient is `1 mod 3`; the general inverse-iterate family, literal source equation, integer construction, uniqueness, and iterate congruences. |
| Version 2: seven Stirling applications | A052895, A064618, A354242, A167137, A305550, A306082, A080253, with full arbitrary-weight eventual-periodicity and least-tail-period results. These remain credited formalizations of previously proved mathematics. |
| Version 1: A396099 | All four assertions and the general consecutive-iterate theorem. |
| Version 1: A396798 | Seven iterate assertions, refutation of the literal incorrect initial phase, and the corrected residue block starting at index two. |
| Version 1: A396807 | Both assertions, including all integer iterates via genuine inverses. |
| Version 1: A393856–A393859 | All six previously handled modulus and parity assertions, with the general scaled-inverse family. |
| Original A396843 project | All 16 `Hanna.Acceptance` endpoints, supporting source, original manuscript source, author and provenance records. |

The Stirling statements are already covered by Payam Danesh's [26 August 2026 preprint](https://doi.org/10.33774/coe-2026-4d6jr), Theorem 4.1 and Corollary 4.2, with a stronger Carmichael bound. They are not new open-problem solutions. The earlier consecutive-iterate case is credited to Shiva Priyan Shanmuga Sundaram. All earlier qualifications remain in the retained papers and archives.

The source repository is [dvgyl/oeis-a396843-proof](https://github.com/dvgyl/oeis-a396843-proof), revision `995e55adcbe06b2a913e24f12ff73a7faf362f06`. No prior DOI has been reassigned to this expanded release.

All earlier Lean modules are byte-for-byte unchanged; the old root contract text is retained after added imports. Both earlier complete ZIPs are embedded verbatim:

| Archive inside `prior_work/` | Unchanged SHA-256 |
|---|---|
| `oeis_congruence_proofs_Dev_Goyal_v1.zip` | `04f347b0e116a1c92cd7a1f21f38a37ae3dfb71c733dd5f55769accd0714489c` |
| `oeis_proofs_complete_Dev_Goyal_v2.zip` | `b28c6de12f53e862b670d37d79d8b5f11333ce3d7acd44e61cb27eb2b99dbc10` |

## Contents

- `manuscript/six_more_oeis_proofs.pdf` and `.tex`: complete mathematics for the six additions.
- `manuscript/further_oeis_proofs.pdf` and `.tex`: unchanged version-two paper.
- `manuscript/compositional_congruences.pdf` and `.tex`: unchanged version-one paper.
- `lean/Round3/`: six new sequence proofs, shared modulus-four arithmetic, and independently written source/type contracts.
- `lean/More/`, `lean/Consecutive/`, `lean/Related/`, and `lean/Hanna/`: all prior formal work.
- `docs/ROUND3_COVERAGE.md`: exact source and theorem map, with limits and index ranges.
- `docs/DIFFERENTIAL_AND_MAHLER_PARITY.md`, `docs/ROUND3_LACUNARY_INVERSE.md`, `docs/ROUND3_SQUARE_REVERSION.md`, `docs/THETA_SUBSTITUTION.md`: detailed proof notes.
- `docs/ROUND3_ELEMENTARY_REVIEW.md`, `docs/ROUND3_LACUNARY_REVIEW.md`, `docs/ROUND3_SQUARE_REVERSION_REVIEW.md`, `docs/THETA_INDEPENDENT_REVIEW.md`: independent AI-assisted semantic reviews.
- `validation/final_theorems.json`: all 226 fixed required endpoints.
- `reproducibility/lean_complete/`: fresh complete build, contract compilation, full printed theorem types, transitive axiom audit, and numerical corroboration records.
- `prior_work/`: both previous complete ZIP deliverables plus original provenance materials.
- `third_party/mathlib/`: attribution and Apache-2.0 license for the earlier adapted upstream Stirling proof code.

## Reproduce the verification

Use Python 3.11 or later and Lean's Elan/Lake toolchain manager. The project pins **Lean 4.19.0** and **Mathlib `c44e0c8ee63ca166450922a373c7409c5d26b00b`**. Compiler binaries and downloaded dependency caches are not bundled; pinned source configuration and the lockfile are included.

```sh
cd lean
lake exe cache get
lake build
cd ..
python3 scripts/check_formalization.py
```

The complete checker removes this project's build cache and builds all **five** libraries. It then directly invokes Lean on every first-party module in dependency order, writing into a newly created, empty object directory. That directory is first on the compiler import path, and the previous project-object directory is removed from the path. This forces source re-elaboration and prevents reuse of cached project proofs. It compiles the old and new typed contracts, prints full theorem types, and audits the transitive axiom dependencies of all 226 fixed endpoints using the newly compiled project objects. It also verifies the actual compiler version, exact dependency revision, all source hashes before and after the run, and preservation of both previous releases.

Only Lean/Mathlib's standard **`propext`, `Classical.choice`, and `Quot.sound`** are accepted as axiom dependencies. Missing or extra audit records, warnings/errors, and other axioms are rejected. The proof sources use no `sorry`, `admit`, `native_decide`, or custom mathematical axioms. The axiom report is in `reproducibility/lean_complete/axioms.log` and `report.json`.

### Independent finite checks

The full checker reruns all nine numerical suites, including every previous suite. The additions can also be run separately:

```sh
python3 scripts/verify_differential_mahler.py --output validation/differential_mahler_numeric.json
python3 scripts/verify_lacunary_inverse.py --degree 80 --output validation/lacunary_inverse_numeric.json
python3 scripts/verify_square_reversion.py --degree 80 --output validation/square_reversion_numeric.json
python3 scripts/verify_theta_substitution.py --output validation/theta_substitution_numeric.json
```

The additions match **all 152 displayed source terms** across the six entries. Exact integer checks cover A397588 through degree 500, A389536 through 2050, A389537 and A389542 through 80, and both theta series through 64. Direct formal-composition checks for A389536 use degree 81; its coefficient recurrence is checked through 2050. These bounds describe corroborating computations, while Lean proves the statements for all indices.

The separate sign-run observation in A389537 and the radius-of-convergence question in A378580 are outside this release's proofs. No general analytic convergence assertion follows merely from these formal-series congruences.

## Papers and archive

Compile each `.tex` with pdfLaTeX twice. Final PDFs are rendered and visually inspected. After the complete validation succeeds, create the release archive with:

```sh
python3 scripts/package_release.py
```

The packager checks that no validated source or evidence log changed, writes `oeis_proofs_complete_Dev_Goyal_v3.zip`, then verifies every payload hash and the ZIP CRCs. `SHA256SUMS` covers the full payload, including both embedded prior ZIPs. After extraction, `sha256sum -c SHA256SUMS` checks the contents on systems that provide it.
